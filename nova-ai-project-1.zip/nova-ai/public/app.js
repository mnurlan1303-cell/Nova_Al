const $ = (id) => document.getElementById(id);
const STORAGE_KEY = 'nova_chats_v1';
let chats = loadChats();
let currentId = null;
let selectedImage = null;
let busy = false;

function loadChats(){ try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]')}catch{return []} }
function saveChats(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(chats)); renderHistory(); }
function newId(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,7); }
function currentChat(){ return chats.find(c=>c.id===currentId); }
function createChat(){ const chat={id:newId(),title:'Yeni söhbət',messages:[],updated:Date.now()}; chats.unshift(chat);currentId=chat.id;saveChats();renderMessages();$('welcome').classList.remove('hidden');closeSidebar();$('promptInput').focus(); }
function renderHistory(){ const box=$('historyList');box.innerHTML='';chats.forEach(chat=>{const b=document.createElement('button');b.className='history-item'+(chat.id===currentId?' active':'');b.textContent=chat.title;b.onclick=()=>{currentId=chat.id;renderHistory();renderMessages();closeSidebar()};box.appendChild(b)}); }
function addMessage(role, content, imageData=null){ const chat=currentChat();if(!chat)return;chat.messages.push({role,content,imageData});chat.updated=Date.now();if(chat.messages.filter(m=>m.role==='user').length===1){chat.title=(typeof content==='string'?content:'Şəkilli mesaj').slice(0,34)||'Yeni söhbət'}chats.sort((a,b)=>b.updated-a.updated);saveChats();renderMessages(); }
function renderMessages(){ const chat=currentChat();const box=$('messages');box.innerHTML='';const has=!!chat?.messages.length;$('welcome').classList.toggle('hidden',has);if(!chat)return;chat.messages.forEach(m=>{const row=document.createElement('div');row.className='message '+m.role;const av=document.createElement('div');av.className='avatar';av.textContent=m.role==='user'?'S':'✦';const body=document.createElement('div');body.className='message-body';if(m.imageData){const img=document.createElement('img');img.src=m.imageData;img.alt='Göndərilmiş şəkil';body.appendChild(img)}if(m.content){const t=document.createElement('div');t.textContent=m.content;body.appendChild(t)}row.append(av,body);box.appendChild(row)});$('conversation').scrollTop=$('conversation').scrollHeight; }
function closeSidebar(){$('sidebar').classList.remove('open')}
function setBusy(v){busy=v;$('sendBtn').disabled=v;$('sendBtn').textContent=v?'…':'↑'}
async function sendMessage(text){ if(busy)return;let chat=currentChat();if(!chat){createChat();chat=currentChat()}const image=selectedImage;selectedImage=null;$('filePreview').textContent='';addMessage('user',text,image);const messages=currentChat().messages.map(m=>{if(m.imageData){return {role:'user',content:[...(m.content?[{type:'input_text',text:m.content}]:[]),{type:'input_image',image_url:m.imageData}]}}return {role:m.role,content:m.content}});setBusy(true);const wait={role:'assistant',content:'NOVA düşünür…'};currentChat().messages.push(wait);renderMessages();try{const response=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages})});const data=await response.json();currentChat().messages.pop();if(!response.ok)throw new Error(data.error||'Sorğu alınmadı.');addMessage('assistant',data.answer)}catch(e){currentChat().messages.pop();addMessage('assistant','Xəta: '+e.message)}finally{setBusy(false);$('promptInput').focus()} }
$('chatForm').addEventListener('submit',e=>{e.preventDefault();const text=$('promptInput').value.trim();if(!text&&!selectedImage)return;$('promptInput').value='';resizeInput();sendMessage(text)});
$('promptInput').addEventListener('input',resizeInput);$('promptInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('chatForm').requestSubmit()}});
function resizeInput(){const el=$('promptInput');el.style.height='auto';el.style.height=Math.min(el.scrollHeight,180)+'px'}
$('newChat').onclick=createChat;$('topNewChat').onclick=createChat;$('openSidebar').onclick=()=>$('sidebar').classList.add('open');$('closeSidebar').onclick=closeSidebar;
$('attachBtn').onclick=()=>$('imageInput').click();$('imageInput').addEventListener('change',e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>5*1024*1024){$('filePreview').textContent='Şəkil 5 MB-dan kiçik olmalıdır.';e.target.value='';return}const reader=new FileReader();reader.onload=()=>{selectedImage=reader.result;$('filePreview').textContent='Şəkil əlavə edildi: '+file.name};reader.readAsDataURL(file);e.target.value=''});
document.querySelectorAll('.suggestion').forEach(b=>b.addEventListener('click',()=>{ $('promptInput').value=b.dataset.prompt;$('chatForm').requestSubmit()}));
if(chats.length){currentId=chats[0].id;renderHistory();renderMessages()}else{renderHistory();$('welcome').classList.remove('hidden')}
