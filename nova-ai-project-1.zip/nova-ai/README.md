# NOVA AI — başlanğıc layihəsi

Bu layihə internetdə yayımlana bilən sadə AI çat saytıdır. İnterfeys mobil ekranlara uyğundur, söhbətləri brauzerin localStorage yaddaşında saxlayır, yeni söhbət açır və şəkil göndərməyi dəstəkləyir.

## Vacib
- OpenAI API açarı brauzerə qoyulmur; yalnız serverdə `OPENAI_API_KEY` mühit dəyişəni kimi saxlanılır.
- API istifadəsi ayrıca ödəniş yarada bilər. İstifadə limitləri və xərcləri hesabda yoxlayın.
- Saytı ictimaiyyətə açmazdan əvvəl istifadəçi hesabları, daha güclü sui-istifadə qorunması və xərc limitləri əlavə etmək tövsiyə olunur.

## Lokal işə salmaq
1. Kompüterdə Node.js 20+ quraşdırın.
2. Layihə qovluğunda `npm install` işlədin.
3. `OPENAI_API_KEY` mühit dəyişəninə öz API açarınızı əlavə edin. Açarı heç vaxt HTML/JS fayllarına və ya ictimai repoya yazmayın.
4. `npm start` işlədin.
5. Brauzerdə `http://localhost:3000` açın.

Modeli dəyişmək üçün serverdə `OPENAI_MODEL` mühit dəyişənini təyin edə bilərsiniz; standart dəyər `gpt-5.5`-dir.

## Yayımlamaq
Node.js serveri işlədə bilən hosting seçin. Layihə fayllarını yerləşdirin, `OPENAI_API_KEY`-i hosting panelində server mühit dəyişəni kimi əlavə edin, sonra tətbiqi başladın. HTTPS aktiv edin. API açarını heç kimə göndərməyin.

## Hazır olanlar
- Chat üslublu qaranlıq interfeys
- Mobil görünüş və yan menyu
- Yeni söhbət və brauzerdə tarixçə
- OpenAI Responses API üçün server endpoint-i
- Mətn və şəkil mesajları
- Sorğu limitləmə və əsas təhlükəsizlik başlıqları

## Hələ əlavə edilməyənlər
- Səsli söhbət
- İstifadəçi hesabları və cihazlararası sinxron tarixçə
- İnternet axtarışı aləti
- Canlı cavab axını (streaming)
- Saytın hostingə yerləşdirilməsi və domen
