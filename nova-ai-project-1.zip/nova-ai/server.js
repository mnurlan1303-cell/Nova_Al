import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.5';

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '8mb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/chat', async (req, res) => {
  try {
    if (!API_KEY) return res.status(503).json({ error: 'Serverdə OPENAI_API_KEY təyin edilməyib.' });
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
      return res.status(400).json({ error: 'Mesaj siyahısı düzgün deyil.' });
    }

    const input = messages.map((m) => {
      if (!['user', 'assistant'].includes(m.role)) throw new Error('Yanlış mesaj rolu.');
      if (typeof m.content === 'string') return { role: m.role, content: m.content.slice(0, 12000) };
      if (m.role !== 'user' || !Array.isArray(m.content)) throw new Error('Yanlış mesaj formatı.');
      const content = m.content.map((part) => {
        if (part.type === 'input_text') return { type: 'input_text', text: String(part.text || '').slice(0, 12000) };
        if (part.type === 'input_image' && typeof part.image_url === 'string' && /^data:image\/(png|jpeg|webp|gif);base64,/.test(part.image_url)) {
          return { type: 'input_image', image_url: part.image_url, detail: 'auto' };
        }
        throw new Error('Şəkil və ya mətn formatı dəstəklənmir.');
      });
      return { role: 'user', content };
    });

    const apiResponse = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        instructions: 'Sən NOVA adlı faydalı, mehriban və təhlükəsiz süni intellekt köməkçisisən. İstifadəçi başqa dil istəmədikcə Azərbaycan dilində cavab ver. Aydın və dürüst ol. Bilmədiyini uydurma.',
        input
      })
    });
    const data = await apiResponse.json();
    if (!apiResponse.ok) {
      console.error('OpenAI API error:', data);
      return res.status(apiResponse.status).json({ error: data?.error?.message || 'AI xidməti sorğunu qəbul etmədi.' });
    }
    const answer = data.output?.flatMap(item => item.content || []).filter(part => part.type === 'output_text').map(part => part.text).join('\n') || '';
    return res.json({ answer: answer || 'Cavab alınmadı. Yenidən cəhd et.' });
  } catch (error) {
    console.error(error);
    return res.status(400).json({ error: error.message || 'Sorğu zamanı xəta baş verdi.' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`NOVA AI hazırdır: http://localhost:${PORT}`));
